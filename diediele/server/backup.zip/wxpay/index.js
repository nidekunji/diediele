var WechatPayment = require('./lib/wx-payment');

module.exports = WechatPayment;
