-- ----------------------------
--  Table structure for `t_level_config`
-- ----------------------------
DROP TABLE IF EXISTS `t_level_config`;
CREATE TABLE `t_level_config` (
  `level` int(11) UNSIGNED NOT NULL,
  `consumes` varchar(500) NOT NULL DEFAULT '' COMMENT '消耗道具',
  `prizes` varchar(500) NOT NULL DEFAULT '' COMMENT '奖励道具',
  `lvlcode` varchar(500) NOT NULL COMMENT '关卡数据',
  UNIQUE KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='关卡配置表';