/*
 Navicat Premium Data Transfer

 Source Server         : Localhost
 Source Server Type    : MySQL
 Source Server Version : 50717
 Source Host           : localhost
 Source Database       : cAuth

 Target Server Type    : MySQL
 Target Server Version : 50717
 File Encoding         : utf-8

 Date: 08/10/2017 22:22:52 PM
*/

SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;
set time_zone = '+8:00';

-- ----------------------------
--  Table structure for `t_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `uid` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `open_id` varchar(100) NOT NULL,
  `uuid` varchar(100) DEFAULT NULL,
  `skey` varchar(100) NOT NULL,
  `session_key` varchar(100) DEFAULT NULL,
  `nickname` varchar(128) NOT NULL DEFAULT '' COMMENT '用户昵称',
  `avatar_url` varchar(255) NOT NULL DEFAULT '' COMMENT '用户头像地址',
  `telephone` int(11) NOT NULL DEFAULT '0' COMMENT '手机号码',
  `gender` tinyint(1) NOT NULL DEFAULT '1' COMMENT '性别，1:男；2:女',
  `country` varchar(30) NOT NULL DEFAULT '' COMMENT '国家',
  `city` varchar(30) NOT NULL DEFAULT '' COMMENT '城市',
  `province` varchar(30) NOT NULL DEFAULT '' COMMENT '省份',
  `language` varchar(30) NOT NULL DEFAULT '' COMMENT '语言',
  `level` int(11) NOT NULL DEFAULT '0' COMMENT '闯关成功的最高关卡',
  `max_level` int(11) NOT NULL DEFAULT '0' COMMENT '历史挑战的最高关卡',
  `paragraph_level` int(11) NOT NULL DEFAULT '0' COMMENT '段位',
  `goldcoin` int(11) NOT NULL DEFAULT '0' COMMENT '金币数量',
  `love` int(11) NOT NULL DEFAULT '0' COMMENT '爱心数量',
  `themes` varchar(500) NOT NULL DEFAULT '' COMMENT '用户拥有的主题',
  `ld_chance` int(11) NOT NULL DEFAULT '0' COMMENT '抽奖_剩余次数',
  `ld_day_share_times` int(11) NOT NULL DEFAULT '0' COMMENT '抽奖_日分享次数',
  `ld_last_share_time` datetime  NOT NULL DEFAULT '1990-01-01 00:00:00' COMMENT '抽奖_最后一次分享时间',
  `last_visit_time` datetime NOT NULL DEFAULT '1990-01-01 00:00:00' COMMENT '最后一次更新时间',
  `last_open_timed_bag_time` datetime NULL COMMENT '最后一次打开礼包的时间',
  `last_lottery_draw_time` datetime NOT NULL DEFAULT '1990-01-01 00:00:00' COMMENT '最后一次抽奖的时间',
  `create_time` datetime NOT NULL DEFAULT '1990-01-01 00:00:00' COMMENT '创建时间',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `open_id` (`open_id`),
  UNIQUE KEY `skey` (`skey`),
  KEY `telephone` (`telephone`),
  KEY `level` (`level`),
  KEY `paragraph_level` (`paragraph_level`),
  KEY `goldcoin` (`goldcoin`),
  KEY `love` (`love`),
  KEY `last_visit_time` (`last_visit_time`),
  KEY `create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户信息表';
ALTER TABLE `t_user`
  MODIFY `uid` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10000;

-- ----------------------------
--  Table structure for `t_user_relation`
-- ----------------------------
DROP TABLE IF EXISTS `t_user_relation`;
CREATE TABLE `t_user_relation` (
  `uid1` int(11) UNSIGNED NOT NULL,
  `uid2` int(11) UNSIGNED NOT NULL,
  UNIQUE KEY `uid1_uid2` (`uid1`, `uid2`),
  KEY `uid1` (`uid1`),
  KEY `uid2` (`uid2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户关系表';

-- ----------------------------
--  Table structure for `t_user_message`
-- ----------------------------
DROP TABLE IF EXISTS `t_user_message`;
CREATE TABLE `t_user_message` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(11) UNSIGNED NOT NULL COMMENT '用户ID',
  `type` tinyint(3) UNSIGNED NOT NULL DEFAULT '1' COMMENT '消息类型, 1:好友帮助成功',
  `scene` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT '场景值',
  `content` text COMMENT '消息内容',
  `create_time` datetime NOT NULL DEFAULT '1990-01-01 00:00:00' COMMENT '创建时间',
  PRIMARY KEY `id` (`id`),
  KEY `uid` (`uid`),
  KEY `scene` (`scene`),
  KEY `create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户消息列表';

-- ----------------------------
--  Table structure for `t_order`
-- ----------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order` (
  `order_id` varchar(32) NOT NULL COMMENT '订单号',
  `uid` int(11) UNSIGNED NOT NULL COMMENT '用户ID',
  `open_id` varchar(100) NOT NULL COMMENT 'openid',
  `total` int(11) NOT NULL DEFAULT 0 COMMENT '订单金额(单位:分)',
  `product_id` varchar(32) NOT NULL COMMENT '商品编号',
  `count` int(11) NOT NULL DEFAULT '1' COMMENT '商品数量',
  `status` tinyint(3) NOT NULL DEFAULT 0 COMMENT '订单状态，0:待付款；1:已付款；2:已过期；3:已取消',
  `pay_time` timestamp COMMENT '支付时间',
  `create_time` datetime NOT NULL DEFAULT '1990-01-01 00:00:00' COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '最后一次更新时间',
  PRIMARY KEY `order_id` (`order_id`),
  KEY `uid` (`uid`),
  KEY `open_id` (`open_id`),
  KEY `total` (`total`),
  KEY `product_id` (`product_id`),
  KEY `count` (`count`),
  KEY `status` (`status`),
  KEY `create_time` (`create_time`),
  KEY `update_time` (`update_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='支付订单表';

-- ----------------------------
--  Table structure for `t_wechat`
-- ----------------------------
DROP TABLE IF EXISTS `t_wechat`;
CREATE TABLE `t_wechat` (
  `access_token` varchar(512) NOT NULL COMMENT '接口调用凭据',
  `access_token_expire_time` int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '接口调用凭据过期时间'
) ENGINE=Myisam DEFAULT CHARSET=utf8 COMMENT='微信公众平台信息表';

INSERT INTO `t_wechat` (`access_token`, `access_token_expire_time`) VALUES ('', 0);

-- ----------------------------
--  Table structure for `t_user_theme_buy_record`
-- ----------------------------
DROP TABLE IF EXISTS `t_user_theme_buy_record`;
CREATE TABLE `t_user_theme_buy_record` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(11) UNSIGNED NOT NULL COMMENT '用户ID',
  `theme_id` varchar(30) NOT NULL COMMENT '主题标识',
  `order_id` varchar(32) NOT NULL DEFAULT '' COMMENT '此字段用于保存付款类型为RMB时的支付订单号',
  `paytype` tinyint(5) NOT NULL DEFAULT 0 COMMENT '付款类型，101:金币道具; 102:爱心道具; 201:RMB',
  `total` int(11) NOT NULL DEFAULT 0 COMMENT '若支付类型为道具，则表示道具数量，若支付类型为RMB，则表示金额(单位:分)',
  `status` tinyint(3) NOT NULL DEFAULT 0 COMMENT '订单状态，0:待付款；1:已付款；2:已过期；3:已取消',
  `create_time` datetime NOT NULL DEFAULT '1990-01-01 00:00:00' COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '最后一次更新时间',
  PRIMARY KEY `id` (`id`),
  KEY `uid` (`uid`),
  KEY `theme_id` (`theme_id`),
  KEY `order_id` (`order_id`),
  KEY `total` (`total`),
  KEY `status` (`status`),
  KEY `create_time` (`create_time`),
  KEY `update_time` (`update_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户主题购买记录';

SET FOREIGN_KEY_CHECKS = 1;
